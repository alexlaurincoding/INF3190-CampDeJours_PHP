<?php	
	interface Config
	{	
		const DB_HOTE = "localhost";
		const DB_UTILISATEUR = "root";
		const DB_PASS = "";
		const DB_NOM = "camps_de_jours";
	}