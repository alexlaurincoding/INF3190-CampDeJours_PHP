<h1>Erreur</h1>

<div class="alert alert-danger mt-4" role="alert">
  <h4 class="alert-heading">Oups! Un problème est survenu...</h4>
  <hr>
  <p><?=Util::message('erreur')?></p>
</div>